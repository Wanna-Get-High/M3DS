#ifndef GLSUPPORT_H
#define GLSUPPORT_H

#include <GL/glew.h>

#include <QGLWidget>

#ifdef __linux
    #include <GL/glu.h>
#endif


#endif // GLSUPPORT_H
