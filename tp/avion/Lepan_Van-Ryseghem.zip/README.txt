Tout fonctionne correctement sans soucis.

Les commandes ont été changé afin de convenir a un clavier qwerty.