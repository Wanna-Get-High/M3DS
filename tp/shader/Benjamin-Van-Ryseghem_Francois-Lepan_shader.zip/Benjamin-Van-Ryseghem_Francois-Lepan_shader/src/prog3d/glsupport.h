#ifndef GLSUPPORT_H
#define GLSUPPORT_H

#include <GL/glew.h>
#include <qgl.h>

#endif // GLSUPPORT_H

