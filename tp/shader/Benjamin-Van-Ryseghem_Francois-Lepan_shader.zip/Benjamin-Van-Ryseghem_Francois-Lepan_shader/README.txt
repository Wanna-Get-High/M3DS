Benjamin Van Ryseghem
Francois Lepan

Toutes les questions ont été faites.

Un petit soucie quant à l'application de l'éclairement spéculaire 
(vecteur normalisé, V -> négatif)