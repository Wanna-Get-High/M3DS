#ifndef GLSUPPORT_H
#define GLSUPPORT_H

#include <GL/glew.h>

#include <QGLWidget>

#endif // GLSUPPORT_H
