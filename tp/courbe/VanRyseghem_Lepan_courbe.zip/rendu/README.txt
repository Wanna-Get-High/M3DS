Benjamin Van Ryseghem
Francois Lepan


Tout fonctionne.

Nous avons rencontré quelques problèmes quant à la compréhension de la résolution du problème de Hermite ainsi que l'implémentation de la fonction CatmullRomCurve::setup.

Mais après coup nous avons compris comment faire :)
